export interface CategoryProps{
  _id: string;
  name: string;
  icon: string;
}
